﻿/// <reference path="GameForest.js" />
/// <reference path="guid.js" />
/// <reference path="jquery.js" />
/// <reference path="promise.js" />
/// <reference path="index.html" />

'use strict';

// gameforest-specific data

GameForestCloudUrl                  = "localhost";
GameForestVerboseMessaging          = false;

// DOM elements

var canvasObject                    = document.getElementById("sampleGameCanvas");
var canvasContex                    = canvasObject.getContext("2d");

// data that is shared between players

var gameData                        = {

	hpDisplay = [ 100, 100 ]
};

var chooseData                      = {

    lightTaken: false,
    darkTaken: false
};

// user-specific data

var finished                        = false;

var myTurn                          = false;
var myToken                         = "";

var darkPlayer                      = null; // we know that dark player is always the second one
var lightPlayer                     = null; // we know that light player is always the first one

var currentPlayer                   = null;

var lightPlayerName                 = "";
var darkPlayerName                  = "";

var showUpdateText                  = false;

// clams "value" from "min" to "max"
Math.clamp                          = function (value, min, max)
{
    if (value <= min)
    {
        return min;
    }
    else if (value >= max)
    {
        return max;
    }

    return value;
};

// game loop

var timer                           = setInterval(function()
{
    canvasContex.clearRect  (0, 0, 800, 480);

    canvasContex.fillStyle  = "white";
    canvasContex.fillRect   (0, 0, 800, 480);

    drawTokens  ();
    drawTile    ();
    drawTurns   ();

}, 1000 / 60);

// game specific functions

function drawTile                   ()
{
    canvasContex.save();

    canvasContex.translate(200, 160);

    canvasContex.strokeRect(0, 0, 350, 90);
	
	canvasContex.moveTo(0, 175);
	canvasContex.lineTo(90, 175);

    canvasContex.stroke();

    canvasContex.restore();
};

function drawTurns                  ()
{
    canvasContex.fillStyle = "black";
    canvasContex.font = "20px arial";

    if (currentPlayer != null && darkPlayer != null)
    {
        if (currentPlayer.UserId == darkPlayer.UserId)
            canvasContex.fillStyle = "red";
        else
            canvasContex.fillStyle = "black";
    }

    canvasContex.fillText("DARK: " + darkPlayerName, 440, 300);

    if (currentPlayer != null && lightPlayer != null)
    {
        if (currentPlayer.UserId == lightPlayer.UserId)
            canvasContex.fillStyle = "red";
        else
            canvasContex.fillStyle = "black";
    }

    canvasContex.fillText("LIGHT: " + lightPlayerName, 250, 300);
};

function drawTokens                 ()
{
    canvasContex.save();
	
	canvasContext.translate(200,160);
	
    canvasContex.textBaseline   = "middle";
    canvasContex.fillStyle      = "black";
    canvasContex.font           = "30px arial";

        for (var x = 0; x < 2; x++)
        {
            var tx = gameData.hpDisplay[x];
			var tp = tx.toString();
            var tm = canvasContex.measureText(tp);

            canvasContex.fillText(tp,(x*175)+((175-tm.width)/2),40);
        }
		
    canvasContex.restore();
};

function useAttack					(evt)
{
	if (myTurn == false)
		return;
	
	var damage = Math.floor((Math.random()*10)+1);
	
	if(myToken == "Light")
	{
		var oldHP = gameData.displayHP[1];
		gameData.displayHP[1] = oldHP - damage;
	} else {
		var oldHP = gameData.displayHP[0];
		gameData.displayHP[0] = oldHP - damage;
	}
	
	$("#sampleGameAttack").prop("disabled", true);
	$("#sampleGameMagic").prop("disabled", true);
	
	//send data asynchronously
	gf.thenStarter()
		.then(function(error, result)
		{
			return gf.sendGameData("GameData", gameData)
		})
		.then(function(error, result)
		{
			return gf.nextTurn();
		})
		.then(function(error, result)
		{
			myTurn = false;
			$("#sampleGameAttack").prop("disabled", false);
			$("#sampleGameMagic").prop("disabled", false);
		});
}

function useMagic					(evt)
{
	if (myTurn == false)
		return;
		
	var heal = Math.floor((Math.random()*10)+2);
	
	if(myToken == "Light")
	{
		var oldHP = gameData.displayHP[0];
		gameData.displayHP[0] = oldHP + heal;
	} else {
		var oldHP = gameData.displayHP[1];
		gameData.displayHP[1] = oldHP + heal;
	}
	
	$("#sampleGameAttack").prop("disabled", true);
	$("#sampleGameMagic").prop("disabled", true);
	
	//send data asynchronously
	gf.thenStarter()
		.then(function(error, result)
		{
			return gf.sendGameData("GameData", gameData)
		})
		.then(function(error, result)
		{
			return gf.nextTurn();
		})
		.then(function(error, result)
		{
			myTurn = false;
			$("#sampleGameAttack").prop("disabled", false);
			$("#sampleGameMagic").prop("disabled", false);
		});
}

function onDocumentReady            ()
{
    // we register events for the game
	
	$("sampleGameAttack").on("click", useAttack);
	$("sampleGameMagic").on("click", useMagic);
};

// gameforest callback methods

GameForest.prototype.onGameStart    = function ()
{
    console.log("OnGameStart is invoked!");

    $("#sampleGameChooseScreen").hide();
    $("#sampleGameActualGame").show();

    var userInfo = null;

    // lol chain starter
    gf.thenStarter()
        .then(function (error, result)
        {
            // get this user's information
            return gf.getUserInfo();
        })
        .then(function (error, result)
        {
            /* returns: GFXUserRow
                {
                    UserId,
                    Password,
                    Username,
                    FirstName,
                    LastName,
                    Description
                }
             */

            console.log("UserId: " + result.UserId + "\nPassword: " + result.Password + "\nUsername: " + result.Username);

            userInfo = result;

            // get player's order
            return gf.getUserOrder();
        })
        .then(function (error, result)
        {
            // we have the user's order number!
            console.log("Player order: " + result);

            if     (result == 1)
            {
                myToken = "Light";

                lightPlayer = userInfo;
            }
            else if (result == 2)
            {
                myToken = "Dark";

                darkPlayer = userInfo;
            }

            return gf.getNextPlayer(1);
        })
        .then(function (error, result)
        {
            /* returns: GFXUserRow
                {
                    UserId,
                    Password,
                    Username,
                    FirstName,
                    LastName,
                    Description
                }
             */

            console.log("Get next player: " + JSON.stringify(result));

            if      (myToken == "Light")
                darkPlayer = result;
            else if (myToken == "Dark")
                lightPlayer = result;

            lightPlayerName = lightPlayer.Username;
            darkPlayerName = darkPlayer.Username;
        });
};

GameForest.prototype.onGameChoose   = function ()
{
    console.log("OnGameChoose is invoked!");

    $("#sampleGameChooseScreen").show();
};

GameForest.prototype.onTurnSelect   = function (originalTurn)
{
    console.log("My turn is " + originalTurn);

    $("#sampleGameButtonChooseL").click(function ()
    {
        console.log("Light token taken!");

        chooseData.lightTaken = true;

        gf.sendGameData("chooseData", chooseData)
            .then(function (error, result)
            {
                gf.confirmTurn(1);
            });
    });

    $("#sampleGameButtonChooseD").click(function ()
    {
        console.log("Dark token taken!");

        chooseData.darkTaken = true;

        gf.sendGameData("chooseData", chooseData)
            .then(function (error, result)
            {
                gf.confirmTurn(2);
            });
    });
};

GameForest.prototype.onTurnStart    = function ()
{
    myTurn      = true;
    finished    = false;

    // check if game is finished

    // Dark wins when Light = 0 HP
    // Light wins when Dark = 0 HP

    var hpTile = [
		// index 0 = light hp
		// index 1 = dark hp
        [ 0, 0 ],

    ];

    // convert gameTile to scoreTile
    for (var y = 0; y < 2; y++)
    {
            var score = gameData.gameTile[y];

            scoreTile[y] = score;
    }

    console.log("Score tile data: ");
	console.log("Light HP: " + scoreTile[0]);
	console.log("Dark HP: " + scoreTile[1]);
	
	var lightHP = scoreTile[0],
		darkHP = scoreTile[1];
	
    if (darkHP <= 0)
    {
        finished = true;

        // Light wins
        gf.finishGame("Light wins");
    }

    if (lightHP <= 0)
    {
        finished = true;

        // Dark wins
        gf.finishGame("Dark wins");
    }

    if (finished == false)
    {
        gf.thenStarter()
            .then(function (error, result)
            {
                return gf.getCurrentPlayer();
            })
            .then(function (error, result)
            {
                console.log(JSON.stringify(result));

                currentPlayer = result;
            });
    }
};

GameForest.prototype.onTurnChange   = function ()
{
    gf.thenStarter()
        .then(function (error, result)
        {
            return gf.getCurrentPlayer();
        })
        .then(function (error, result)
        {
            console.log(JSON.stringify(result));

            currentPlayer = result;
        });
};

GameForest.prototype.onUpdateData   = function (key, updatedData)
{
    console.log(gf.getLobbyState());

    if      (gf.getLobbyState() == GFX_STATUS_CHOOSE)
    {
        console.log(updatedData.darkTaken);
        console.log(updatedData.lightTaken);

        if (updatedData.darkTaken)
        {
            $("#sampleGameButtonChooseD").prop("disabled", true);
        }
        
        if (updatedData.lightTaken)
        {
            $("#sampleGameButtonChooseL").prop("disabled", true);
        }

        chooseData = updatedData;
    }
    else if (gf.getLobbyState() == GFX_STATUS_PLAYING)
    {
        gameData = updatedData;
    }
};

GameForest.prototype.onGameFinish   = function (tallyList)
{
    alert(tallyList);

    gf.navigateToGame();
};
